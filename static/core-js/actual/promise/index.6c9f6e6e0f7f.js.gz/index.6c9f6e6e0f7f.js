'use strict';
var parent = require('../../stable/promise');
require('../../modules/esnext.promise.with-resolvers');

module.exports = parent;
