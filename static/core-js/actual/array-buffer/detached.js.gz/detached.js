'use strict';
require('../../stable/array-buffer');
require('../../modules/esnext.array-buffer.detached');
