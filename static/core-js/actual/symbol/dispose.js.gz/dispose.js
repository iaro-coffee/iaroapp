'use strict';
require('../../modules/esnext.symbol.dispose');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('dispose');
