'use strict';
var parent = require('../../stable/symbol');

require('../../modules/esnext.function.metadata');
require('../../modules/esnext.symbol.async-dispose');
require('../../modules/esnext.symbol.dispose');
require('../../modules/esnext.symbol.metadata');

module.exports = parent;
