'use strict';
var parent = require('../../stable/data-view');
require('../../modules/esnext.data-view.get-float16');
require('../../modules/esnext.data-view.set-float16');

module.exports = parent;
