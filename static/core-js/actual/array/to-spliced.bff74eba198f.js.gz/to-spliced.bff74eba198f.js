'use strict';
var parent = require('../../stable/array/to-spliced');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.array.to-spliced');

module.exports = parent;
