'use strict';
require('../../../modules/esnext.array.group-by');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Array', 'groupBy');
