'use strict';
var parent = require('../../../stable/array/virtual/to-sorted');
// TODO: Remove from `core-js@4`
require('../../../modules/esnext.array.to-sorted');

module.exports = parent;
