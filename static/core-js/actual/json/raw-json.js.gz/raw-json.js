'use strict';
require('../../modules/es.object.create');
require('../../modules/es.object.freeze');
require('../../modules/esnext.json.raw-json');
var path = require('../../internals/path');

module.exports = path.JSON.rawJSON;
