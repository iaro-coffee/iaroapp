'use strict';
require('../../modules/es.object.keys');
require('../../modules/esnext.json.parse');
var path = require('../../internals/path');

module.exports = path.JSON.parse;
