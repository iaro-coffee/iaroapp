'use strict';
require('../../modules/esnext.json.is-raw-json');
var path = require('../../internals/path');

module.exports = path.JSON.isRawJSON;
