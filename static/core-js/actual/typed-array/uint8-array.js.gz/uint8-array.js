'use strict';
var parent = require('../../stable/typed-array/uint8-array');
require('../../actual/typed-array/methods');

module.exports = parent;
