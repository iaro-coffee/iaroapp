'use strict';
var parent = require('../../stable/typed-array/float64-array');
require('../../actual/typed-array/methods');

module.exports = parent;
