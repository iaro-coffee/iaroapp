'use strict';
var parent = require('../../stable/object/group-by');
require('../../modules/esnext.object.group-by');

module.exports = parent;
