'use strict';
// https://github.com/tc39/proposal-is-usv-string
require('../modules/esnext.string.is-well-formed');
require('../modules/esnext.string.to-well-formed');
