'use strict';
// https://github.com/tc39/proposal-promise-with-resolvers
require('../modules/esnext.promise.with-resolvers');
