'use strict';
// https://github.com/tc39/proposal-decorator-metadata
require('../modules/esnext.function.metadata');
require('../modules/esnext.symbol.metadata');
