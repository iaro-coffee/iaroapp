'use strict';
// https://github.com/tc39/proposal-symbol-predicates
require('../modules/esnext.symbol.is-registered');
require('../modules/esnext.symbol.is-well-known');
