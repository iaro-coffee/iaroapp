'use strict';
// https://github.com/tc39/proposal-float16array
require('../modules/esnext.data-view.get-float16');
require('../modules/esnext.data-view.set-float16');
require('../modules/esnext.math.f16round');
