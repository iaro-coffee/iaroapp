'use strict';
// https://github.com/tc39/proposal-array-grouping
require('../modules/esnext.map.group-by');
require('../modules/esnext.object.group-by');
