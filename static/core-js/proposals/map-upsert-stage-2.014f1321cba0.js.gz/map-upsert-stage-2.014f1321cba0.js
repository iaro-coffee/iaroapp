'use strict';
// https://github.com/tc39/proposal-upsert
require('../modules/esnext.map.emplace');
require('../modules/esnext.weak-map.emplace');
