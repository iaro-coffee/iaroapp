'use strict';
// https://github.com/tc39/proposal-Number.range
require('../modules/esnext.iterator.constructor');
require('../modules/esnext.iterator.range');
