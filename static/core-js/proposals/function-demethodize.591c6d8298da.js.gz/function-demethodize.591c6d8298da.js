'use strict';
// https://github.com/js-choi/proposal-function-demethodize
require('../modules/esnext.function.demethodize');
