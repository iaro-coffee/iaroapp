'use strict';
// https://github.com/tc39/proposal-arraybuffer-base64
require('../modules/esnext.uint8-array.from-base64');
require('../modules/esnext.uint8-array.from-hex');
require('../modules/esnext.uint8-array.to-base64');
require('../modules/esnext.uint8-array.to-hex');
