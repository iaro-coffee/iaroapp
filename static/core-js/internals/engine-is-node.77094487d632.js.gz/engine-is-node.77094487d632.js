'use strict';
var global = require('../internals/global');
var classof = require('../internals/classof-raw');

module.exports = classof(global.process) === 'process';
