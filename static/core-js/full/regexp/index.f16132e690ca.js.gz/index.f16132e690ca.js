'use strict';
var parent = require('../../actual/regexp');
require('../../modules/esnext.regexp.escape');

module.exports = parent;
