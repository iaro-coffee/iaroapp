'use strict';
require('../../modules/esnext.regexp.escape');
var path = require('../../internals/path');

module.exports = path.RegExp.escape;
