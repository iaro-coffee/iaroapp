'use strict';
require('../../modules/esnext.reflect.get-metadata');
var path = require('../../internals/path');

module.exports = path.Reflect.getMetadata;
