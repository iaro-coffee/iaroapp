'use strict';
var parent = require('../../actual/object');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.object.has-own');
require('../../modules/esnext.object.iterate-entries');
require('../../modules/esnext.object.iterate-keys');
require('../../modules/esnext.object.iterate-values');

module.exports = parent;
