'use strict';
require('../../modules/es.symbol');
require('../../modules/esnext.symbol.is-well-known');
var path = require('../../internals/path');

module.exports = path.Symbol.isWellKnown;
