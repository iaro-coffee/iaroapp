'use strict';
require('../../modules/es.symbol');
require('../../modules/esnext.symbol.is-registered-symbol');
var path = require('../../internals/path');

module.exports = path.Symbol.isRegisteredSymbol;
