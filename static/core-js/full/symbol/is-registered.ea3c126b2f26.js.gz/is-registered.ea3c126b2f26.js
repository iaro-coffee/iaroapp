'use strict';
require('../../modules/es.symbol');
require('../../modules/esnext.symbol.is-registered');
var path = require('../../internals/path');

module.exports = path.Symbol.isRegistered;
