'use strict';
require('../../../modules/esnext.function.un-this');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Function', 'unThis');
