'use strict';
require('../../../modules/esnext.function.demethodize');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Function', 'demethodize');
