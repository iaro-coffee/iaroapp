'use strict';
require('../../modules/esnext.function.is-callable');
var path = require('../../internals/path');

module.exports = path.Function.isCallable;
