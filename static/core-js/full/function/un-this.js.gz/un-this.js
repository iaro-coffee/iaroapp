'use strict';
require('../../modules/esnext.function.un-this');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Function', 'unThis');
