'use strict';
require('../../modules/esnext.function.demethodize');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Function', 'demethodize');
