'use strict';
require('../../modules/esnext.function.is-constructor');
var path = require('../../internals/path');

module.exports = path.Function.isConstructor;
