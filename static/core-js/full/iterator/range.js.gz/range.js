'use strict';
require('../../modules/es.object.to-string');
require('../../modules/esnext.iterator.constructor');
require('../../modules/esnext.iterator.range');
var path = require('../../internals/path');

module.exports = path.Iterator.range;
