'use strict';
var parent = require('../../../actual/array/virtual/at');

// TODO: Remove from `core-js@4`
require('../../../modules/esnext.array.at');

module.exports = parent;
