'use strict';
require('../../modules/es.string.from-code-point');
require('../../modules/es.weak-map');
require('../../modules/esnext.string.dedent');
var path = require('../../internals/path');

module.exports = path.String.dedent;
