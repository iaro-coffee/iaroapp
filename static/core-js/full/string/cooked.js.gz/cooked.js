'use strict';
require('../../modules/esnext.string.cooked');
var path = require('../../internals/path');

module.exports = path.String.cooked;
