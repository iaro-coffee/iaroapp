'use strict';
var parent = require('../../actual/typed-array/uint16-array');
require('../../full/typed-array/methods');

module.exports = parent;
