'use strict';
var parent = require('../../actual/typed-array/uint32-array');
require('../../full/typed-array/methods');

module.exports = parent;
