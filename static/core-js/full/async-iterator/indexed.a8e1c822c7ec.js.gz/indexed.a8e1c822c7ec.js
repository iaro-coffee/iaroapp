'use strict';
// TODO: Remove from `core-js@4`
require('../../modules/es.object.to-string');
require('../../modules/es.promise');
require('../../modules/esnext.async-iterator.constructor');
require('../../modules/esnext.async-iterator.indexed');

var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('AsyncIterator', 'indexed');
