'use strict';
require('../../modules/web.url');
require('../../modules/web.url.can-parse');
var path = require('../../internals/path');

module.exports = path.URL.canParse;
