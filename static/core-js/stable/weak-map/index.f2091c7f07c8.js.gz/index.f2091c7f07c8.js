'use strict';
var parent = require('../../es/weak-map');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
