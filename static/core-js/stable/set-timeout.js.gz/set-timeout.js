'use strict';
require('../modules/web.timers');
var path = require('../internals/path');

module.exports = path.setTimeout;
