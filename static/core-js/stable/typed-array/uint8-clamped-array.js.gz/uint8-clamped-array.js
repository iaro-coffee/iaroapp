'use strict';
var parent = require('../../es/typed-array/uint8-clamped-array');
require('../../stable/typed-array/methods');

module.exports = parent;
