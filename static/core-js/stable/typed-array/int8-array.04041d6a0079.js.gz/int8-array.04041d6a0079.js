'use strict';
var parent = require('../../es/typed-array/int8-array');
require('../../stable/typed-array/methods');

module.exports = parent;
