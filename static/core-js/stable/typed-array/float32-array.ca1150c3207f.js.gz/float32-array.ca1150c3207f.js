'use strict';
var parent = require('../../es/typed-array/float32-array');
require('../../stable/typed-array/methods');

module.exports = parent;
