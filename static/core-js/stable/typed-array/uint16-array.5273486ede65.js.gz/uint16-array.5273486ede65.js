'use strict';
var parent = require('../../es/typed-array/uint16-array');
require('../../stable/typed-array/methods');

module.exports = parent;
