'use strict';
require('../../modules/es.error.to-string');
require('../../modules/web.dom-exception.constructor');
require('../../modules/web.dom-exception.stack');
var path = require('../../internals/path');

module.exports = path.DOMException;
