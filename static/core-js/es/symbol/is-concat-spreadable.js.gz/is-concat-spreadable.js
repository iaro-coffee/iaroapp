'use strict';
require('../../modules/es.array.concat');
require('../../modules/es.symbol.is-concat-spreadable');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('isConcatSpreadable');
