'use strict';
require('../../modules/es.array.iterator');
require('../../modules/es.object.to-string');
require('../../modules/es.set');
require('../../modules/es.string.iterator');
var path = require('../../internals/path');

module.exports = path.Set;
