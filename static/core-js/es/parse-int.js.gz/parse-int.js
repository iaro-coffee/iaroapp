'use strict';
require('../modules/es.parse-int');
var path = require('../internals/path');

module.exports = path.parseInt;
