'use strict';
require('../../modules/es.reflect.has');
var path = require('../../internals/path');

module.exports = path.Reflect.has;
