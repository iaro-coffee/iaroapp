'use strict';
require('../../modules/es.reflect.own-keys');
var path = require('../../internals/path');

module.exports = path.Reflect.ownKeys;
