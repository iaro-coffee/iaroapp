'use strict';
require('../../modules/es.date.to-gmt-string');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Date', 'toGMTString');
