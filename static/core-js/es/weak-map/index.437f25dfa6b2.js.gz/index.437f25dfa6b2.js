'use strict';
require('../../modules/es.array.iterator');
require('../../modules/es.object.to-string');
require('../../modules/es.weak-map');
var path = require('../../internals/path');

module.exports = path.WeakMap;
