'use strict';
require('../../modules/es.object.create');
require('../../modules/es.object.group-by');

var path = require('../../internals/path');

module.exports = path.Object.groupBy;
