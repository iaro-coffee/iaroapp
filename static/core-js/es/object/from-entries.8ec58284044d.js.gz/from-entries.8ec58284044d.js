'use strict';
require('../../modules/es.array.iterator');
require('../../modules/es.object.from-entries');
var path = require('../../internals/path');

module.exports = path.Object.fromEntries;
