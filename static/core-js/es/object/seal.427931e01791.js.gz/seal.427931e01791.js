'use strict';
require('../../modules/es.object.seal');
var path = require('../../internals/path');

module.exports = path.Object.seal;
