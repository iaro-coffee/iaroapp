'use strict';
require('../../modules/es.regexp.constructor');
require('../../modules/es.regexp.dot-all');
require('../../modules/es.regexp.exec');

module.exports = function (it) {
  return it.dotAll;
};
