'use strict';
require('../../modules/es.math.asinh');
var path = require('../../internals/path');

module.exports = path.Math.asinh;
