'use strict';
require('../../modules/es.math.log10');
var path = require('../../internals/path');

module.exports = path.Math.log10;
