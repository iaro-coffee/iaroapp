'use strict';
require('../../modules/es.math.clz32');
var path = require('../../internals/path');

module.exports = path.Math.clz32;
