'use strict';
require('../../modules/es.array.is-array');
var path = require('../../internals/path');

module.exports = path.Array.isArray;
