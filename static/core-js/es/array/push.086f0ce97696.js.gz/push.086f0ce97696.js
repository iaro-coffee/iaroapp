'use strict';
require('../../modules/es.array.push');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'push');
