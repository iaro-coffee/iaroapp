'use strict';
require('../../modules/es.array.flat');
require('../../modules/es.array.unscopables.flat');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'flat');
