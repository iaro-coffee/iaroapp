'use strict';
require('../../modules/es.number.parse-float');
var path = require('../../internals/path');

module.exports = path.Number.parseFloat;
