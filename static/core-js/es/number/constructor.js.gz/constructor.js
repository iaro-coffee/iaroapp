'use strict';
require('../../modules/es.number.constructor');
var path = require('../../internals/path');

module.exports = path.Number;
