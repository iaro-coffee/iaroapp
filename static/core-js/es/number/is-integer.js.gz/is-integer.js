'use strict';
require('../../modules/es.number.is-integer');
var path = require('../../internals/path');

module.exports = path.Number.isInteger;
