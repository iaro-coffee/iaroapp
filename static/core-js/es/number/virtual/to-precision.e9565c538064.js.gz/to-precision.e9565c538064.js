'use strict';
require('../../../modules/es.number.to-precision');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Number', 'toPrecision');
