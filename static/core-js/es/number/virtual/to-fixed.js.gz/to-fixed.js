'use strict';
require('../../../modules/es.number.to-fixed');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('Number', 'toFixed');
