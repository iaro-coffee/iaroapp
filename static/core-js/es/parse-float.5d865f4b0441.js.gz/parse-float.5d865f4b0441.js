'use strict';
require('../modules/es.parse-float');
var path = require('../internals/path');

module.exports = path.parseFloat;
