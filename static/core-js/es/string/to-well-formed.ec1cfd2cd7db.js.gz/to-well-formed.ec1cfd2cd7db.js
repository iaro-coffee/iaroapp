'use strict';
require('../../modules/es.string.to-well-formed');

module.exports = require('../../internals/entry-unbind')('String', 'toWellFormed');
