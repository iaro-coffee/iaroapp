'use strict';
require('../../modules/es.string.from-code-point');
var path = require('../../internals/path');

module.exports = path.String.fromCodePoint;
