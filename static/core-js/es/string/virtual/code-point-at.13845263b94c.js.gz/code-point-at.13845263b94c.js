'use strict';
require('../../../modules/es.string.code-point-at');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('String', 'codePointAt');
