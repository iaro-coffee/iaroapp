'use strict';
require('../../../modules/es.object.to-string');
require('../../../modules/es.string.iterator');
var Iterators = require('../../../internals/iterators');

module.exports = Iterators.String;
