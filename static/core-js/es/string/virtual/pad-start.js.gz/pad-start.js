'use strict';
require('../../../modules/es.string.pad-start');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('String', 'padStart');
