'use strict';
require('../../../modules/es.string.anchor');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('String', 'anchor');
