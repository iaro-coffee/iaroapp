'use strict';
require('../../../modules/es.string.ends-with');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('String', 'endsWith');
