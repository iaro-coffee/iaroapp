'use strict';
require('../../../modules/es.string.trim-start');
var getBuiltInPrototypeMethod = require('../../../internals/get-built-in-prototype-method');

module.exports = getBuiltInPrototypeMethod('String', 'trimLeft');
